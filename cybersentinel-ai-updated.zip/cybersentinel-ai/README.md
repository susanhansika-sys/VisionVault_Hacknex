# CYBERSENTINEL AI
*Turning Security Logs into Actionable Threat Intelligence.*

Prototype decision-support website for AI-Powered Cyber Threat Intelligence. It correlates simulated security events into possible attack chains with evidence-backed, rule-based explanations. No trained ML is implemented, and alerts need human investigation.

## Run
```
npm install
npm run dev
```
Open the URL Vite prints (http://localhost:5173).

## Structure
- `src/data.js`: simulated scenarios A/B/C (swap for API calls later)
- `src/App.jsx`: layout, state provider, and all seven pages
- `src/styles.css`: theming (dark/light), responsive and print styles

## Demo tips
Switch scenarios in the top bar, then open Attack Chains and click timeline events and graph nodes. Use Investigations to change status and Reports to export CSV or print.
