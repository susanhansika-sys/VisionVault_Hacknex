# CyberSentinel AI - Hackathon Build & Demo Guide

## 1. Run the project

Open a terminal in this folder:

```bash
npm install
npm run dev
```

Open the local URL shown by Vite.

For a production check:

```bash
npm run build
npm run preview
```

## 2. What was added

### Explainable AI correlation layer
- Dedicated **AI Analysis** page.
- Correlation risk score out of 100.
- Evidence confidence percentage.
- Attack pattern classification.
- Correlation time window.
- Factor-by-factor reasoning with points.
- AI-generated investigation narrative.
- False-positive safeguards.
- Evidence chain showing the event sequence.

### Dashboard improvements
- AI correlation banner on the Overview page.
- Attack confidence and correlation risk KPIs.
- Current assessment card with pattern, event count and time window.
- Stronger language explaining that a pattern is suspicious, not automatically confirmed malicious.

### Attack Chain improvements
- Correlation banner and confidence visible beside the timeline.
- Existing relationship graph retained.
- Timeline and graph evidence remain clickable.

### Report improvements
- Report includes the correlation assessment, pattern and confidence.

## 3. Recommended judge demo

Use the scenario selector at the top.

### Step A - Start with Scenario C (Benign)

Say:

> "Before showing an attack, I want to show the false-positive problem. These three events include a login, file access and a transfer. But context matters. The user, device, source and destination all match the baseline, so the system classifies this as a benign baseline match with high confidence."

Then open **AI Analysis**.

Point out:
- Known identity + device
- Authorized resource
- Approved destination
- 97% confidence
- 12/100 risk

### Step B - Switch to Scenario A

Say:

> "Now the event types are not enough to tell the story by themselves. Our engine connects them."

Show:

1. Unusual login
2. Restricted file probing
3. Sensitive database export
4. Large external transfer

Then open **AI Analysis**.

Say:

> "The important signal is the relationship between these events. They share the same account and device, happen within six minutes, and follow a suspicious order: access, collect, export, transfer."

Point to:
- 87/100 correlation risk
- 91% confidence
- Possible Data Exfiltration
- Factor-by-factor evidence
- False-positive safeguards

### Step C - Open Attack Chains

Say:

> "Instead of forcing an analyst to read hundreds of log lines, CyberSentinel reconstructs the connected story as a timeline and relationship graph."

Click:
- Timeline event
- User node
- Device node
- Destination node

### Step D - Open Investigations

Say:

> "The system does not automatically take destructive action. It gives the analyst the missing questions and recommended next steps."

Show:
- Information missing
- Recommended next steps
- Investigation status controls

### Step E - Open Reports

Show:
- Executive summary
- AI correlation assessment
- Event evidence
- Related entities
- Recommended actions

Mention CSV export and printable report.

## 4. If a judge asks: "Is this really AI?"

Use this answer:

> "This six-hour prototype uses an explainable AI-style correlation engine rather than pretending we trained a large machine-learning model. It extracts behavioral signals, correlates entities and temporal sequences, scores the evidence, and generates a structured explanation. The architecture is intentionally transparent so an analyst can see why the system reached its assessment."

If asked about production:

> "In production, this correlation layer can be replaced or augmented with trained anomaly-detection and graph-learning models while keeping the same evidence and analyst workflow."

## 5. What not to claim

Do not say:
- "We trained an ML model".
- "The system proves an attack happened".
- "The IP addresses are real malicious infrastructure".
- "The dashboard automatically blocks attackers".

Instead say:
- "Explainable correlation engine".
- "Possible attack pattern".
- "Simulated security data".
- "Decision support for human investigation".

## 6. Six-hour priority order

If you have limited time, do the demo in this order:

1. Run and verify the project.
2. Verify Scenario C benign flow.
3. Verify Scenario A attack flow.
4. Verify AI Analysis page.
5. Verify Attack Chains graph.
6. Verify Investigations page.
7. Verify Reports export/print.
8. Practice the 2-minute demo.
9. Only then spend time on visual polish.

## 7. Core pitch

> **CyberSentinel AI connects the dots.**
>
> Traditional security monitoring can generate separate alerts for an unusual login, restricted access, a database export and an external transfer. Each alert can have a legitimate explanation. CyberSentinel correlates identity, device, time and destination to reconstruct the larger behavioral story. It explains why the combination is suspicious, provides a confidence score, and recommends what an analyst should investigate next. It also demonstrates the other side of the problem: when the same types of activity match a known baseline, the system keeps the risk low instead of creating another false alarm.
